
import javax.swing.*;
import github.group.login.VehicleLoginController;


public class CallControllers{
	private static VehicleLoginController logCon;
	public static void main(String args[]){
		logCon = new VehicleLoginController();
		JFrame frame = new JFrame("VEHICLE REGISTRATION");
		logCon.loginController(frame);
	}
}